import java.io.*;
import java.util.*;

public class Inventory {
    public static void main(String[] args) throws IOException {
        // 启动处理
        InventoryManager manager = new InventoryManager();
        manager.startTask();
    }
}

class InventoryManager {
    // 各存档文件名\
    String inventoryFileName = "C:/Users/hyl/Desktop/javaExperience/Experience3/Code/Inventory.txt",
            transactionsFileName = "C:/Users/hyl/Desktop/javaExperience/Experience3/Code/Transactions.txt",
            ShippingFileName = "C:/Users/hyl/Desktop/javaExperience/Experience3/Code/Shipping.txt",
            errorsFileName = "C:/Users/hyl/Desktop/javaExperience/Experience3/Code/Errors.txt",
            newInventoryFileName = "C:/Users/hyl/Desktop/javaExperience/Experience3/Code/NewInventory.txt";

    // 读写IO
    BufferedReader inventory, transactions;
    BufferedWriter shipping, errors, newInventory;

    // 库存列表
    Vector<Item> items;

    // 删除序列
    LinkedList<Integer> deleteQueue;
    // Order序列，Order记录
    Vector<Order> orderQueue, orders;

    InventoryManager() throws IOException {
        // 初始化文件
        File ShippingFile = new File(ShippingFileName);
        File errorsFile = new File(errorsFileName);
        File newInventoryFile = new File(newInventoryFileName);

        // 如果存档文件不存在，自动创建存档文件
        if (!ShippingFile.exists()) {
            ShippingFile.createNewFile();
            System.out.println("创建存档文件成功！");
        }
        if (!errorsFile.exists()) {
            errorsFile.createNewFile();
            System.out.println("创建存档文件成功！");
        }
        if (!newInventoryFile.exists()) {
            newInventoryFile.createNewFile();
            System.out.println("创建存档文件成功！");
        }

        // 启动IO，初始化容器
        inventory = new BufferedReader(new FileReader(new File(inventoryFileName)));
        transactions = new BufferedReader(new FileReader(new File(transactionsFileName)));
        shipping = new BufferedWriter(new FileWriter(ShippingFile));
        errors = new BufferedWriter(new FileWriter(errorsFile));
        newInventory = new BufferedWriter(new FileWriter(newInventoryFile));
        items = new Vector<Item>();
        deleteQueue = new LinkedList<Integer>();
        orderQueue = new Vector<Order>();
        orders = new Vector<Order>();
    }

    void add(Item item) {
        items.add(item);
    }

    void startTask() throws IOException {// 主任务
        String record;
        String[] substr;
        // 读入库存记录
        while ((record = inventory.readLine()) != null) {
            substr = record.split("\t");// 以tab来分割字符记录 字段用tab分隔
            add(new Item(Integer.valueOf(substr[0]), Integer.valueOf(substr[1]), substr[2], substr[3]));
            System.out.println("读入库存成功！");
        }
        inventory.close(); // 读取库存完成

        // 对每条记录
        while ((record = transactions.readLine()) != null) {
            char operator = record.charAt(0);// 取第一个字符 是操作类型
            switch (operator) {
                case 'A':// 直接添加新品种货物
                    substr = record.split("\t");
                    items.add(new Item(Integer.valueOf(substr[1]), 0, substr[2], substr[3]));
                    break;
                case 'O':// 在订单队列中加入此订单
                    substr = record.split("\t");
                    orderQueue.add(new Order(Integer.valueOf(substr[1]), Integer.valueOf(substr[2]), substr[3]));
                    break;
                case 'R':// 接收货物，增加库存
                    substr = record.split("\t");
                    int ID = Integer.valueOf(substr[1]);
                    int quantity = Integer.valueOf(substr[2]);
                    for (Item i : items) {
                        if (i.ID == ID) {
                            i.quantity += quantity; // 增加库存
                            break;
                        }
                    }
                    break;
                case 'D':// 在删除队列加入此条记录
                    substr = record.split("\t");
                    deleteQueue.add(Integer.valueOf(substr[1]));
                    break;
                default:
                    System.out.println("订单有误！");
                    System.exit(-1);
            }
        }
        transactions.close();// 操作读取完毕
        // 此时已完成A和R操作,后面进行O和D操作

        // 从数目较小的订单开始遍历
        Collections.sort(orderQueue); // 对订单排序
        for (Order order : orderQueue) {
            for (Item item : items) {
                if (item.ID == order.ID) {// 找到目标库存
                    if (item.quantity >= order.quantity) {// 数量充足
                        item.quantity -= order.quantity;// 进行出货操作
                        boolean get = false;
                        // 查找重复的情况，若查询成功则将其合并
                        for (Order ship : orders) {
                            if (ship.ID == order.ID && ship.custom.equals(order.custom)) {
                                ship.quantity += order.quantity;
                                get = true;
                                break;
                            }
                        }
                        if (!get) {// 在未查询成功的前提下，添加此记录
                            orders.add(order);
                        }
                    } else {// 数量不足，则需要写入error文件错误信息。
                        errors.write("对客户：" + order.custom + "发货：" + order.ID + "失败,需要" + order.quantity
                                + "才能成功,但现在存货余量仅有" + item.quantity + "\n");
                        System.out.println("有一个产品出现错误！");
                    }
                    break;
                }
            }
        }

        // 删除的情况
        for (Integer ID : deleteQueue) {
            Item tobedelete = null;
            for (Item item : items) {
                if (item.ID == ID && item.quantity == 0) {// 判断是否满足条件
                    tobedelete = item;
                    break;
                }
            }
            if (tobedelete != null) {
                items.remove(tobedelete); // 发现满足条件，则对货物进行删除
            } else {
                errors.write("删除货物" + ID + "失败\n"); // 未找到符合条件的库存
                System.out.println("有一个产品出现错误！");
            }
        }
        errors.close();

        save();// 保存情况

    }

    void save() throws IOException {
        Collections.sort(items);// 以ID升序排列库存
        for (Item item : items) {
            newInventory.write(item.ID + "\t" + item.quantity + "\t" + item.supplier + "\t" + item.description + "\n");
        }
        for (Order order : orders) {
            shipping.write("对：" + order.custom + "发货：" + order.ID + "，数量为" + order.quantity + "\n");
        }
        // 关闭IO
        errors.close();
        shipping.close();
        newInventory.close();
        System.out.println("操作成功~");
    }

    // 订单根据需求数量来比较大小
    class Order implements Comparable<Order> { // 调用接口，重写比较方法
        public int ID, quantity;
        public String custom;

        Order(int ID, int quantity, String custom) {
            this.ID = ID;
            this.quantity = quantity;
            this.custom = custom;
        }

        @Override
        public int compareTo(Order o) {
            return this.quantity - o.quantity; // 重写比较方法，添加新的比较方式。
        }
    }
}

// 货物根据ID来进行排序
class Item implements Comparable<Item> { // 调用接口，以便于对货物id进行排序。
    public int ID, quantity;
    public String supplier, description;

    Item() {
    }

    Item(int ID, int quantity, String supplier, String description) {
        this.ID = ID;
        this.quantity = quantity;
        this.supplier = supplier;
        this.description = description;
    }

    void add(int quantity) {
        this.quantity += quantity;
    }

    @Override
    public int compareTo(Item o) { // 重写的排序方法
        return this.ID - o.ID;
    }
}
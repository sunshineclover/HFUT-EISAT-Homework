import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

class Server {
	static ServerSocket serverSocket = null;
	static Socket cilent = null;
	static TextArea recoder = new TextArea(25, 60);

	public static void main(String[] args) {
		JFrame jFrame = new JFrame("Server服务器");
		jFrame.setSize(500, 500);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.setResizable(false);
		jFrame.setVisible(true);
		JPanel north = new JPanel();
		JPanel center = new JPanel();
		JPanel south = new JPanel();
		jFrame.add(north, BorderLayout.NORTH);// Java Frame 边界布局
		jFrame.add(center, BorderLayout.CENTER);
		jFrame.add(south, BorderLayout.SOUTH);
		JButton start = new JButton("Start");
		TextField port = new TextField("8000"); // 准备连接 端口名称
		TextField message = new TextField(40);
		north.add(new JLabel("port:"));
		north.add(port);
		north.add(start);
		recoder.setBackground(new Color(232, 242, 254));// 设置背景颜色
		center.add(recoder);
		JButton say = new JButton("Say");
		south.add(new JLabel("Say"));
		south.add(message);
		south.add(say);
		start.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					start.setEnabled(false);
					int i = Integer.parseInt(port.getText());
					recoder.append("Server starting…\n");
					recoder.append("Server port:" + port.getText() + "\n");
					serverSocket = new ServerSocket(i);
					cilent = serverSocket.accept();
					recoder.append("Client connected…\n"); // 满足实验需求，添加指定文字
					ServerThread sThread = new ServerThread();
					sThread.start();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		say.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				PrintWriter pWriter;
				try {
					pWriter = new PrintWriter(cilent.getOutputStream());
					String string = message.getText();
					if (string != "") {
						recoder.append("Server:" + string + "\n");
						pWriter.write("Server:" + string + "\n");
						pWriter.flush(); // 刷新流
					}
					message.setText("");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		jFrame.addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				try {
					serverSocket.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}
		});
	}

	static class ServerThread extends Thread { // 线程内操作 实现双向通讯
		public void run() {
			try {
				InputStreamReader IPR1 = new InputStreamReader(cilent.getInputStream());
				BufferedReader bufferedReader1 = new BufferedReader(IPR1);
				String string = bufferedReader1.readLine();
				while (string != null && !string.equals("Client:bye")) { // 以bye作为通信结束标志
					recoder.append(string + "\n");
					string = bufferedReader1.readLine();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
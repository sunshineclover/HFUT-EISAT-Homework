import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

class Client {
	static Socket cilent = null;
	static TextArea recoder = new TextArea(25, 60);// 11

	public static void main(String[] args) {
		JFrame jFrame = new JFrame("Client客户端"); // 新建一个GUI窗口
		jFrame.setSize(500, 500);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.setResizable(false);
		jFrame.setVisible(true);
		JPanel north = new JPanel();// 添加面板
		JPanel center = new JPanel();
		JPanel south = new JPanel();
		jFrame.add(north, BorderLayout.NORTH); // Java Frame 边界布局
		jFrame.add(center, BorderLayout.CENTER);
		jFrame.add(south, BorderLayout.SOUTH);
		JButton start = new JButton("Connect");// 满足题目要求，设置一个按钮
		TextField IP = new TextField("127.0.0.01");// 文字域上显示IP，端口信息
		TextField port = new TextField("8000");//
		TextField message = new TextField(40);// 之后传入的信息
		north.add(new JLabel("IP:"));
		north.add(IP);
		north.add(new JLabel("port:"));
		north.add(port);
		north.add(start);
		recoder.setBackground(new Color(253, 156, 174)); // 设置背景颜色
		center.add(recoder);
		JButton say = new JButton("Say"); // 设置通信的按钮
		south.add(new JLabel("Say:"));
		south.add(message);
		south.add(say);
		jFrame.addWindowListener(new WindowListener() { // 监听接口，监听窗口的相关信息

			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				try {
					cilent.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}
		});
		start.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					start.setEnabled(false);
					int i = Integer.parseInt(port.getText());
					recoder.append("Client port:" + port.getText() + "\n");
					recoder.append("Server IP adress:" + IP.getText() + "\n");
					cilent = new Socket(IP.getText(), i); // 套接字
					recoder.append("Connect to server…\n"); // 满足实验需求，添加指定文字
					ClientThread cThread = new ClientThread(); // 设置客户端线程
					cThread.start();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		say.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				PrintWriter pWriter;
				try {
					pWriter = new PrintWriter(cilent.getOutputStream());
					String string = message.getText();
					if (string != "") {
						recoder.append("Client:" + string + "\n");
						pWriter.write("Client:" + string + "\n");
						pWriter.flush(); // 刷新流
					}
					message.setText("");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	}

	static class ClientThread extends Thread {
		public void run() { // 线程的方法如下：
			try {
				InputStreamReader IPR1 = new InputStreamReader(cilent.getInputStream());
				BufferedReader bufferedReader1 = new BufferedReader(IPR1);
				String string = bufferedReader1.readLine(); // 读取文本
				while (string != null && !string.equals("Server:bye")) { // 终止通信的判断标志：bye
					recoder.append(string + "\n");
					string = bufferedReader1.readLine();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
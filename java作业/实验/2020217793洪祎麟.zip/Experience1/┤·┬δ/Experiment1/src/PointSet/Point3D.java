
package PointSet;

import java.util.Scanner;

public class Point3D extends Point2D {
	protected int z;

	Point3D(int x, int y, int z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	Point3D(Point2D p, int z) {
		this.x = p.x;
		this.y = p.y;
		this.z = z;
	}

	public void offset(int a, int b, int c) {
		this.x += a;
		this.y += b;
		this.z += c;
	}

	public static void main(String args[]) {
		Point2D p2d1 = new Point2D(0, 0);
		Point2D p2d2 = new Point2D(2, 2);
		System.out.println("a的坐标为" + "(" + p2d1.x + "," + p2d1.y + ")");
		System.out.println("b的坐标为" + "(" + p2d2.x + "," + p2d2.y + ")");
		Scanner read = new Scanner(System.in);
		System.out.print("2d中两点的距离为：");
		System.out.println(Math.sqrt(Math.pow((p2d1.x - p2d2.x), 2) + Math.pow((p2d1.y - p2d2.y), 2)));
		System.out.println("平移前a的坐标为" + "(" + p2d1.x + "," + p2d1.y + ")");

		int a, b, c;
		a = read.nextInt();
		b = read.nextInt();
		p2d1.offset(a, b);
		System.out.println("平移后的坐标为" + "(" + p2d1.x + "," + p2d1.y + ")");
		System.out.print("2d中两点的距离为：");
		System.out.println(Math.sqrt(Math.pow((p2d1.x - p2d2.x), 2) + Math.pow((p2d1.y - p2d2.y), 2)));
		Point3D p3d1 = new Point3D(0, 0, 0);
		Point3D p3d2 = new Point3D(2, 2, 2);
		System.out.println("a的坐标为" + "(" + p3d1.x + "," + p3d1.y + "," + p3d1.z + ")");
		System.out.println("b的坐标为" + "(" + p3d2.x + "," + p3d2.y + "," + p3d2.z + ")");
		System.out.print("3d中两点的距离为：");
		System.out.println(Math.sqrt(
				Math.pow((p3d1.x - p3d2.x), 2) + Math.pow((p3d1.y - p3d2.y), 2) + Math.pow((p3d1.z - p3d2.z), 2)));
		System.out.println("平移前a的坐标为" + "(" + p3d1.x + "," + p3d1.y + "," + p3d1.z + ")");
		a = read.nextInt();
		b = read.nextInt();
		c = read.nextInt();
		p3d1.offset(a, b, c);
		System.out.println("平移后的坐标为" + "(" + p3d1.x + "," + p3d1.y + "," + p3d1.z + ")");
		System.out.print("3d中两点的距离为：");
		System.out.println(Math.sqrt(
				Math.pow((p3d1.x - p3d2.x), 2) + Math.pow((p3d1.y - p3d2.y), 2) + Math.pow((p3d1.z - p3d2.z), 2)));
	}
}

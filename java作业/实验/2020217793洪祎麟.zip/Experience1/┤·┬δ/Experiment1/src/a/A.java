package a;

public class A{
	public void functionA(){
		System.out.println("hello,This is in package a and class A");
	}
}


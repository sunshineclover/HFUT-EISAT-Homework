package b;
import a.A;
public class B{
	public void functionB(){
		System.out.println("hello,This is in package b and class B");
	}
	
	
	public static void main(String args[]){
		A hyl01 = new A();
		B hyl02 = new B();
		hyl01.functionA();
		hyl02.functionB();
	}
}

